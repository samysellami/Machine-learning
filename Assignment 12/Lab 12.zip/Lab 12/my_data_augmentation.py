import cv2
import numpy as np
from matplotlib import pyplot as plt


def add_blur(image):
    value = np.random.rand(1, 1)[0]
    if value < 0.3:
        print('average blur')
        blur = cv2.blur(image, (5, 5))
    elif value >= 0.3 and value < 0.66:
        print('gaussian blur')
        blur = cv2.GaussianBlur(image, (5, 5), 0)
    else:
        print('median blur')
        blur = cv2.medianBlur(image, 5)
    return blur


def add_salt_and_paper(image):
    s_vs_p = np.random.rand(1, 1)[0]
    print('s_vs_p: {}'.format(s_vs_p))
    amount = 0.1 * np.random.rand(1, 1)[0]
    print('amount {}'.format(amount))
    out = np.copy(image)
    # Salt mode
    num_salt = np.ceil(amount * image.size * s_vs_p)
    coords = [np.random.randint(0, i - 1, int(num_salt))
              for i in image.shape]
    out[coords] = 1

    # Pepper mode
    num_pepper = np.ceil(amount * image.size * (1. - s_vs_p))
    coords = [np.random.randint(0, i - 1, int(num_pepper))
              for i in image.shape]
    out[coords] = 0
    return out


def generate_augmented_image(image, chance_blur=0.3, chance_noise=0.4):
    chances = np.random.rand(1, 2)
    if chances[0, 0] <= chance_blur:
        print('Add blur')
        image = add_blur(image)
    else:
        print('No blur')
    if chances[0, 1] <= chance_noise:
        print('Add noise')
        image = add_salt_and_paper(image)
    else:
        print('No noise')
    return image


def main():
    image_name = 'cat.jpg'
    # read image
    image = cv2.imread("data/{}".format(image_name))
    b, g, r = cv2.split(image)
    rgb_img = cv2.merge([r, g, b])
    augmented_image = generate_augmented_image(
        rgb_img, chance_blur=0.7, chance_noise=0.8)
    plt.imshow(augmented_image)
    plt.show()


if __name__ == '__main__':
    main()
